function ConverterEmDolar() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  var valorEmRealNumerico = parseFloat(valor);
  var valorEmDolar = valorEmRealNumerico * 2;
  var elementoValorConvertido = document.getElementById("valorConvertido");
  var valorConvertido = "U$ " + valorEmDolar.toFixed(2);
  elementoValorConvertido.innerHTML = valorConvertido;
}

function ConverterEmEuro() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  var valorEmRealNumerico = parseFloat(valor);
  var valorEmEuro = valorEmRealNumerico * 3;
  var elementoValorConvertido = document.getElementById("valorConvertido");
  var valorConvertido = "€ " + valorEmEuro.toFixed(2);
  elementoValorConvertido.innerHTML = valorConvertido;
}

function ConverterEmBitcoin() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  var valorEmRealNumerico = parseFloat(valor);
  var valorEmBitcoin = valorEmRealNumerico * 100;
  var elementoValorConvertido = document.getElementById("valorConvertido");
  var valorConvertido = valorEmBitcoin.toFixed(2) + " Bitcoins";
  elementoValorConvertido.innerHTML = valorConvertido;
}

function ConverterTodos() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  var valorEmRealNumerico = parseFloat(valor);
  var valorEmDolar = valorEmRealNumerico * 2;
  var valorEmEuro = valorEmRealNumerico * 3;
  var valorEmBitcoin = valorEmRealNumerico * 100;
  var elementoValorDolarConvertido = document.getElementById("valorConvertido");
  var valorDolarConvertido = "U$ " + valorEmDolar.toFixed(2);
  var elementoValorEuroConvertido = document.getElementById("valorConvertido2");
  var valorEuroConvertido = "€ " + valorEmEuro.toFixed(2);
  var elementoValorBitcoinConvertido = document.getElementById(
    "valorConvertido3"
  );
  var valorBitcoinConvertido = valorEmBitcoin.toFixed(2) + " Bitcoins";
  elementoValorDolarConvertido.innerHTML = valorDolarConvertido;
  elementoValorEuroConvertido.innerHTML = valorEuroConvertido;
  elementoValorBitcoinConvertido.innerHTML = valorBitcoinConvertido;
}

// criar botão de conversão para Euro
// criar outro conversor de anos x velocidade da luz
// criar conversor de litros de Gasolina
// criar conversor de temperatura
// valor em bitcoins
